<?php
include ('fufiConnection.php');

$connection = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);

$json = file_get_contents('php://input');
error_log("$json");
$obj = json_decode($json, true);
//$obj = json_decode($json, true, JSON_OBJECT_AS_ARRAY);
error_log("$obj");
$username = $_REQUEST['username']; //($obj['username']);	//$obj[1];	//[1];	//['username'];
$email =  $_REQUEST['email']; //($obj['email']);	//$obj[0]; //['email'];
$baseUrl = 'localhost/fufiWebsite';//$obj['baseUrl'];
$deleteAccountConfirm = '/deleteAccountConfirmation.html';
error_log("$username");
$login_query = "SELECT * FROM `users` WHERE `username` = '$username' and `email` = '$email'";
$check = mysqli_query($connection, $login_query);



//check if below can be replaced with check[0] to get userID
//$userID_query = "SELECT `users.userID` FROM `users` WHERE `username` = '$username'";
//$check2 = mysqli_query($connection, $userID_query);

//if(isset($obj['username'], $obj['email'])){
if(isset($username, $email)) {
	error_log("check of presence okay");
	$z = mysqli_fetch_row($check); 
//	$z2 = mysqli_fetch_row($check2);
	if(mysqli_num_rows($check) == 1) {
		//print_r('success');
		//this is added in place of above
		print_r('success');//, $z2);
		
		error_log("successfully checked 2");

		//TODO generate random token to be stored in database for comparison with email
		$resetToken = rand(7, 7000) + rand(17, 70000) + rand(70, 770000);
		
		//save the token and details to account deletion table
		$sql = "INSERT INTO `accountDeletion` (`username`, `email`, `resetToken`) VALUES ('$username', '$email', '$resetToken')";
//		$sql = "INSERT INTO accountDeletion(userName, email, resetToken) VALUES ('$username', '$email', '$resetToken')";
//		create a link using the token
//		send the name and email to the actual delete confirmation page
	
		if(mysqli_query($connection, $sql)){
		//send to user a reset link email
			$to = "$email";
			$subject = "DELETE YOUR FUFI INFORMATION";
	////		$message = "Hello, We have received an information deletion request on your account. Click on this <a href=\"$baseUrl .$resetToken \">link</a> to delete your information. Please note that we will not be able to assist you to recover the information and once the database backups are deleted the information is gone for good. If this is an error please disregard this message.";
			$message = "Hello, We have received an information deletion request on your account. Please click on <a href=\"$baseUrl .$deleteAccountConfirm \">link</a> and enter $resetToken to delete your information. Please note that we will not be able to assist you to recover the information and once the database backups are deleted the information is gone for good. If this is an error please disregard this message.";		
			$from = "admin@airesol.org";
			$headers = "From:" . $from;
			
			mail($to, $subject, $message, $headers);
			echo "Success. Information deletion request received. Please Check your email and confirm the request.";
		
		
		
		//resest below
		//change below to delete
		//$sql  = "DELETE FROM `users` WHERE `users`.`username` = \'$username'"; //or use email
		
	/*	if(mysqli_query($connection, $sqlQuery)) {
			$successMSG = 'Password Reset Successful';
			$json = json_encode($successMSG);
			echo $json;		
		}			
		else {
			echo 'Try again';
		}*/
		//save values to deletion database to await confirmation

			}else {
				echo "Sorry we cannot complete the request at the moment. Please try again later.";
			}
	}else {
		print_r('failed to delete');
	}
}else {
	print_r('please register to fufi to continue us to continue');
}
mysqli_close($connection);
?>