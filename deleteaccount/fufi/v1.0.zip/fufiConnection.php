<?php
$HostName = "localhost";
$HostUser = "cudohwk6_fufi_user";
$HostPass = "tizi#hapa1";
$DatabaseName = "cudohwk6_fufi_db";
/*
try{
    $fuficon = new PDO("mysql:host=$HostName;dbname=$DatabaseName,$HostUser,$HostPass");
    //set pdo err to exception
    $fuficon->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
    echo "Connected Successfully";
} catch (PDOException $e){
	echo "Connection Failed: " . $e->getMessage();
}
//$miradicon = null; //close

mysqli_report(MYSQLI_REPORT_ERROR|MYSQLI_REPORT_STRICT);
*/
$fuficon2 = mysqli_connect($HostName, $HostUser, $HostPass, $DatabaseName);